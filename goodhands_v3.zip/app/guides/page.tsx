export const metadata = {
  title: 'Guides — Good Hands',
  description: 'Discover neighbourhood‑by‑neighbourhood guides and tips for experiencing beauty in Lisbon.'
};

const guides = [
  {
    slug: 'chiado-guide',
    title: 'Chiado Beauty Guide',
    excerpt: 'Where to get a flawless blowout and the best coffee in Lisbon’s chicest quarter.',
    date: '2025-05-10'
  },
  {
    slug: 'belem-guide',
    title: 'Belém Glow Guide',
    excerpt: 'A day of self‑care by the river — from skincare stops to sunset drinks.',
    date: '2025-04-18'
  },
  {
    slug: 'sintra-guide',
    title: 'Sintra Bridal Scout',
    excerpt: 'Planning the perfect destination wedding? Start with our Sintra favourites.',
    date: '2025-03-30'
  }
];

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function GuidesPage() {
  return (
    <main className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-3xl md:text-4xl font-semibold mb-6">Guides</h1>
        <p className="mb-8 max-w-2xl text-ink/70">Plan your next self‑care day or event with our curated neighbourhood guides. From hidden salons to scenic photo spots, we share the local knowledge.</p>
        <div className="space-y-10">
          {guides.map(guide => (
            <article key={guide.slug} className="flex flex-col md:flex-row gap-6 border-b border-harbor/30 pb-6">
              <div className="flex-1">
                <h2 className="text-xl font-semibold mb-2"><a href={`/guides/${guide.slug}`} className="hover:text-gold transition-colors">{guide.title}</a></h2>
                <p className="text-sm text-ink/70 mb-2">{guide.excerpt}</p>
                <time className="text-xs text-ink/50">{formatDate(guide.date)}</time>
              </div>
              <div className="md:w-40 md:flex-shrink-0 h-32 bg-porcelain flex items-center justify-center rounded-xl">
                <span className="text-ink/50">Image</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}