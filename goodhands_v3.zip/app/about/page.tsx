export const metadata = {
  title: 'About — Good Hands',
  description: 'Learn about our philosophy and commitment to curated beauty experiences.'
};

export default function AboutPage() {
  return (
    <main className="py-20">
      <div className="max-w-4xl mx-auto px-6 space-y-8">
        <h1 className="text-3xl md:text-4xl font-semibold">About Good Hands</h1>
        <p className="text-lg text-ink/80">Good Hands is a beauty concierge platform built for those who value design, craft and a sense of belonging. Inspired by curated travel platforms like Boutique Homes and Design Hotels, we believe that beauty is more than a service — it’s an experience rooted in trust, locality and culture.</p>
        <p className="text-lg text-ink/80">We handpick the most talented stylists and artisans in Lisbon and beyond. Every appointment, retreat and event we curate is infused with care, creativity and connection. Our Journal and Guides celebrate the stories and places that inspire us, while our Experiences bring them to life.</p>
        <p className="text-lg text-ink/80">Whether you’re preparing for a wedding, seeking a restorative getaway, or simply looking to elevate your daily self‑care, we’re here to ensure you feel understood and taken care of. You’re in good hands.</p>
      </div>
    </main>
  );
}