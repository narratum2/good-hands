import { Services } from '../../components/Services';

export const metadata = {
  title: 'Services — Good Hands',
  description: 'Explore our curated menu of blowouts, hairstyling, makeup and brow services.'
};

export default function ServicesPage() {
  return (
    <main className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-3xl md:text-4xl font-semibold mb-6">Our Services</h1>
        <p className="mb-8 max-w-2xl text-ink/70">Select from our signature blowouts, glamorous makeup and expertly crafted brows. Each service is delivered by a vetted professional in Lisbon.</p>
        <Services />
      </div>
    </main>
  );
}