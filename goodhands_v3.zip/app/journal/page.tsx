export const metadata = {
  title: 'Journal — Good Hands',
  description: 'Read stories, insights and inspiration from the worlds of beauty, design and well‑being.'
};

const posts = [
  {
    slug: 'lisbon-beauty-guide',
    title: 'A Designer’s Guide to Beauty in Lisbon',
    excerpt: 'Explore our favourite salons, spas and secret spots for self‑care in the city.',
    date: '2025-08-12'
  },
  {
    slug: 'bridal-trend-report',
    title: 'Bridal Trend Report 2025',
    excerpt: 'From soft glam to statement hair, discover what’s inspiring brides this season.',
    date: '2025-07-28'
  },
  {
    slug: 'retreat-calm',
    title: 'Escaping to Find Calm: Behind Our Retreats',
    excerpt: 'A look at how we craft restorative experiences on the coast and countryside.',
    date: '2025-06-20'
  }
];

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function JournalPage() {
  return (
    <main className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-3xl md:text-4xl font-semibold mb-6">Journal</h1>
        <p className="mb-8 max-w-2xl text-ink/70">Our Journal shares stories and insights at the intersection of beauty, design and well‑being. Stay inspired and informed.</p>
        <div className="space-y-10">
          {posts.map(post => (
            <article key={post.slug} className="flex flex-col md:flex-row gap-6 border-b border-harbor/30 pb-6">
              <div className="flex-1">
                <h2 className="text-xl font-semibold mb-2"><a href={`/journal/${post.slug}`} className="hover:text-gold transition-colors">{post.title}</a></h2>
                <p className="text-sm text-ink/70 mb-2">{post.excerpt}</p>
                <time className="text-xs text-ink/50">{formatDate(post.date)}</time>
              </div>
              <div className="md:w-40 md:flex-shrink-0 h-32 bg-porcelain flex items-center justify-center rounded-xl">
                <span className="text-ink/50">Image</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}