export const metadata = {
  title: 'Experiences — Good Hands',
  description: 'Discover immersive beauty experiences from bridal preparations to restorative retreats and corporate pampering.'
};

const experiences = [
  {
    slug: 'weddings',
    title: 'Weddings',
    desc: 'Bespoke bridal beauty packages for your big day.',
    href: '/premium/weddings',
  },
  {
    slug: 'retreats',
    title: 'Retreats',
    desc: 'Rejuvenating weekend escapes by the sea or countryside.',
    href: '/premium/retreats',
  },
  {
    slug: 'corporate',
    title: 'Corporate',
    desc: 'On‑site beauty services for events, shoots and VIP guests.',
    href: '/premium/corporate',
  },
];

export default function ExperiencesPage() {
  return (
    <main className="py-20">
      <div className="max-w-7xl mx-auto px-6">
        <h1 className="text-3xl md:text-4xl font-semibold mb-6">Experiences</h1>
        <p className="mb-8 max-w-2xl text-ink/70">Elevate your self‑care with our curated experiences designed to delight. From bespoke bridal services to restorative retreats and high‑touch corporate events, we handle every detail.</p>
        <div className="grid gap-8 md:grid-cols-3">
          {experiences.map((exp) => (
            <a key={exp.slug} href={exp.href} className="block rounded-2xl overflow-hidden shadow-sm ring-1 ring-harbor/30 bg-white transition-transform hover:scale-[1.02]">
              <div className="h-40 bg-porcelain flex items-center justify-center">
                <span className="text-xl font-semibold text-ink">{exp.title}</span>
              </div>
              <div className="p-4">
                <p className="text-sm text-ink/70 mb-2">{exp.desc}</p>
                <span className="text-sm font-medium text-gold hover:underline">Learn more →</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </main>
  );
}