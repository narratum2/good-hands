import { Hero } from '../components/Hero';
import { SearchBar } from '../components/SearchBar';
import { CategoriesRow } from '../components/CategoriesRow';
import { Services } from '../components/Services';
import { ExperiencesPreview } from '../components/ExperiencesPreview';
import { GuidesPreview } from '../components/GuidesPreview';
import { JournalPreview } from '../components/JournalPreview';
import { BookingForm } from '../components/BookingForm';
import { Lookbook } from '../components/Lookbook';
import { FAQ } from '../components/FAQ';

export default function HomePage() {
  return (
    <main>
      {/* Hero with tagline */}
      <Hero />

      {/* Search bar to quickly find a service slot */}
      <section className="-mt-12 md:-mt-16 mb-12 relative z-10">
        <SearchBar />
      </section>

      {/* Category row for quick navigation */}
      <CategoriesRow />

      {/* Core services listing */}
      <Services />

      {/* Curated experiences preview */}
      <ExperiencesPreview />

      {/* Guides preview */}
      <GuidesPreview />

      {/* Journal articles preview */}
      <JournalPreview />

      {/* Booking form for quick request */}
      <section className="py-20 px-6 bg-porcelain">
        <div className="mx-auto max-w-4xl">
          <BookingForm />
        </div>
      </section>

      {/* Lookbook gallery */}
      <Lookbook />

      {/* Frequently asked questions */}
      <FAQ />
    </main>
  );
}