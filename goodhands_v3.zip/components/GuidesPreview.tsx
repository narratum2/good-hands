import Image from 'next/image';

// Sample guides data.  Each guide includes a slug, title, excerpt, and
// corresponding image representing a neighbourhood or destination.  Guides
// provide deeper local insights, akin to travel guides on boutique travel
// platforms.
const guides = [
  {
    slug: 'chiado-beauty-guide',
    title: 'Chiado Beauty Guide',
    excerpt: 'The best salons, boutiques and hidden gems in Lisbon’s cultural heart…',
    image: '/lookbook/placeholder/chiado-guide.jpg'
  },
  {
    slug: 'sintra-bridal-guide',
    title: 'Sintra Bridal Guide',
    excerpt: 'Plan your fairytale wedding look in one of Portugal’s most romantic towns…',
    image: '/lookbook/placeholder/sintra-guide.jpg'
  },
  {
    slug: 'cascais-photo-guide',
    title: 'Cascais Photo Guide',
    excerpt: 'Where to go and what to wear for stunning seaside shoots…',
    image: '/lookbook/placeholder/cascais-guide.jpg'
  }
];

export function GuidesPreview() {
  return (
    <section className="py-20 bg-porcelain" id="guides">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="text-3xl md:text-4xl font-semibold text-center mb-12">Guides & Inspo</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {guides.map(guide => (
            <a key={guide.slug} href={`/guides/${guide.slug}`} className="group block overflow-hidden rounded-2xl shadow-sm ring-1 ring-harbor/30">
              <div className="relative h-56 w-full overflow-hidden">
                <Image
                  src={guide.image}
                  alt={guide.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="text-lg font-semibold mb-2 text-ink group-hover:text-gold transition-colors">
                  {guide.title}
                </h3>
                <p className="text-sm text-ink/70">
                  {guide.excerpt}
                </p>
              </div>
            </a>
          ))}
        </div>
        <div className="text-center mt-8">
          <a href="/guides" className="inline-block px-6 py-3 bg-gold text-ink font-medium rounded-md hover:bg-gold/90 transition-colors">
            Explore all guides
          </a>
        </div>
      </div>
    </section>
  );
}