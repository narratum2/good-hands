"use client";

import { useState } from 'react';

const SERVICES = [
  { id: 'blowout', label: 'Signature Blowout' },
  { id: 'hairstyling', label: 'Event Hairstyling' },
  { id: 'makeup', label: 'Makeup & Glam' },
  { id: 'brows', label: 'Brow Styling' },
];

/**
 * A simple search bar inspired by boutique travel sites.  It allows users to
 * quickly select the type of service they need along with the preferred date
 * and time.  This component does not perform any actual search itself; it
 * simply collects the data and triggers a callback when the user submits
 * the form.  Consumers can use the collected values to filter services or
 * prefill a booking form.  On small screens the inputs stack vertically,
 * while on larger viewports they align horizontally.
 */
export function SearchBar({ onSearch }: { onSearch?: (criteria: { service: string; date: string; time: string }) => void }) {
  const [criteria, setCriteria] = useState({
    service: SERVICES[0].id,
    date: '',
    time: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCriteria(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(criteria);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white/90 backdrop-blur rounded-xl shadow-lg ring-1 ring-harbor/20 p-4 flex flex-col md:flex-row gap-4 md:gap-2 w-full max-w-3xl mx-auto">
      <select
        name="service"
        value={criteria.service}
        onChange={handleChange}
        className="flex-1 p-2 rounded-md border border-harbor/50 bg-white focus:outline-none focus:ring-2 focus:ring-gold text-sm"
      >
        {SERVICES.map(({ id, label }) => (
          <option key={id} value={id}>{label}</option>
        ))}
      </select>
      <input
        type="date"
        name="date"
        value={criteria.date}
        onChange={handleChange}
        className="flex-1 p-2 rounded-md border border-harbor/50 bg-white focus:outline-none focus:ring-2 focus:ring-gold text-sm"
        placeholder="Date"
      />
      <input
        type="time"
        name="time"
        value={criteria.time}
        onChange={handleChange}
        className="flex-1 p-2 rounded-md border border-harbor/50 bg-white focus:outline-none focus:ring-2 focus:ring-gold text-sm"
        placeholder="Time"
      />
      <button type="submit" className="bg-gold text-ink font-medium rounded-md px-4 py-2 text-sm hover:bg-gold/90 transition-colors">
        Search
      </button>
    </form>
  );
}