import Image from 'next/image';

const experiences = [
  {
    slug: 'premium/weddings',
    title: 'Weddings & Events',
    excerpt: 'Curated packages for trials, day‑of styling and onsite touch‑ups.',
    image: '/lookbook/placeholder/weddings-experience.jpg'
  },
  {
    slug: 'premium/retreats',
    title: 'Retreats & Wellness',
    excerpt: 'Seaside escapes and wellness weekends for mind, body and beauty.',
    image: '/lookbook/placeholder/retreats-experience.jpg'
  },
  {
    slug: 'premium/corporate',
    title: 'Corporate & VIP',
    excerpt: 'On‑call styling for executives, speakers and important events.',
    image: '/lookbook/placeholder/corporate-experience.jpg'
  }
];

export function ExperiencesPreview() {
  return (
    <section className="py-20 bg-shell" id="experiences">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="text-3xl md:text-4xl font-semibold text-center mb-12">Curated Experiences</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {experiences.map(exp => (
            <a key={exp.slug} href={`/${exp.slug}`} className="group block overflow-hidden rounded-2xl shadow-sm ring-1 ring-harbor/30">
              <div className="relative h-56 w-full overflow-hidden">
                <Image
                  src={exp.image}
                  alt={exp.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-4 bg-white">
                <h3 className="text-lg font-semibold mb-2 text-ink group-hover:text-gold transition-colors">
                  {exp.title}
                </h3>
                <p className="text-sm text-ink/70">
                  {exp.excerpt}
                </p>
              </div>
            </a>
          ))}
        </div>
        <div className="text-center mt-8">
          <a href="/experiences" className="inline-block px-6 py-3 bg-gold text-ink font-medium rounded-md hover:bg-gold/90 transition-colors">
            View all experiences
          </a>
        </div>
      </div>
    </section>
  );
}