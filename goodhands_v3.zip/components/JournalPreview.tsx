import Image from 'next/image';

// Sample journal posts.  In a real application these would be fetched from
// a CMS or database.  Each entry includes a slug for navigation, a title,
// publication date, a short excerpt and a placeholder image path.
const posts = [
  {
    slug: 'beauty-rituals-for-wellbeing',
    title: 'Beauty Rituals for Well‑Being',
    date: 'August 20, 2025',
    excerpt: 'Elevate your daily routine with mindful practices that nourish both body and spirit…',
    image: '/lookbook/placeholder/beauty-rituals.jpg'
  },
  {
    slug: 'lisbon-light-how-to-shine',
    title: 'Lisbon Light: How to Shine',
    date: 'July 12, 2025',
    excerpt: 'The unique luminosity of Lisbon calls for specific beauty tricks. We share our tips…',
    image: '/lookbook/placeholder/lisbon-light.jpg'
  },
  {
    slug: 'wedding-beauty-timeline',
    title: 'Your Wedding Beauty Timeline',
    date: 'May 18, 2025',
    excerpt: 'From trials to touch‑ups, here’s how to plan your perfect bridal glow…',
    image: '/lookbook/placeholder/wedding-timeline.jpg'
  }
];

/**
 * Preview list for journal articles.  Displays a few featured posts on the
 * homepage with images, titles, publication dates and short excerpts.  Each
 * card links through to the full article page (to be implemented later).
 */
export function JournalPreview() {
  return (
    <section className="py-20 bg-shell" id="journal">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="text-3xl md:text-4xl font-semibold text-center mb-12">From the Journal</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {posts.map(post => (
            <a key={post.slug} href={`/journal/${post.slug}`} className="group block overflow-hidden rounded-2xl shadow-sm ring-1 ring-harbor/30">
              <div className="relative h-56 w-full overflow-hidden">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-4 bg-white">
                <p className="text-sm text-ink/60 mb-1">{post.date}</p>
                <h3 className="text-lg font-semibold mb-2 text-ink group-hover:text-gold transition-colors">
                  {post.title}
                </h3>
                <p className="text-sm text-ink/70">
                  {post.excerpt}
                </p>
              </div>
            </a>
          ))}
        </div>
        <div className="text-center mt-8">
          <a href="/journal" className="inline-block px-6 py-3 bg-gold text-ink font-medium rounded-md hover:bg-gold/90 transition-colors">
            Read more stories
          </a>
        </div>
      </div>
    </section>
  );
}