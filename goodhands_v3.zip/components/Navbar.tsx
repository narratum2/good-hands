export function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-porcelain/95 backdrop-blur border-b border-harbor/50">
      <nav className="mx-auto max-w-7xl flex items-center justify-between px-6 py-4">
        <a href="/" className="text-lg font-semibold tracking-tight hover:text-gold transition-colors">Good Hands</a>
        <div className="hidden md:flex space-x-6 text-sm font-medium">
          {/* Primary navigation links inspired by curated travel platforms */}
          <a href="/services" className="hover:text-gold transition-colors">Services</a>
          <a href="/experiences" className="hover:text-gold transition-colors">Experiences</a>
          <a href="/journal" className="hover:text-gold transition-colors">Journal</a>
          <a href="/guides" className="hover:text-gold transition-colors">Guides</a>
          <a href="/about" className="hover:text-gold transition-colors">About</a>
          <a href="/premium/membership" className="hover:text-gold transition-colors">Membership</a>
        </div>
      </nav>
    </header>
  );
}