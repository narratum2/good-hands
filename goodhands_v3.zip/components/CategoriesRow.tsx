import { HairDryer, Wand2, Brush, Sparkles } from 'lucide-react';

const categories = [
  {
    id: 'blowout',
    label: 'Blowouts',
    icon: HairDryer
  },
  {
    id: 'hairstyling',
    label: 'Hairstyling',
    icon: Wand2
  },
  {
    id: 'makeup',
    label: 'Makeup',
    icon: Sparkles
  },
  {
    id: 'brows',
    label: 'Brows',
    icon: Brush
  }
];

/**
 * Horizontal row of service categories inspired by curated travel site category
 * pickers.  Each category is represented by an icon and a label.  Clicking
 * a category scrolls the user to the corresponding section of the page.
 */
export function CategoriesRow() {
  return (
    <nav className="bg-porcelain py-6">
      <div className="mx-auto max-w-7xl flex flex-wrap justify-center gap-6 px-6">
        {categories.map(({ id, label, icon: Icon }) => (
          <a
            key={id}
            href={`#${id}`}
            className="flex flex-col items-center text-ink hover:text-gold transition-colors"
          >
            <span className="mb-2">
              <Icon className="h-6 w-6" />
            </span>
            <span className="text-sm font-medium">
              {label}
            </span>
          </a>
        ))}
      </div>
    </nav>
  );
}